# API Endpoints

## POST `/api/activities`
Logs an activity to the database.
- Request: `{ activity: "Planted a Tree" }`
- Requires user to be authenticated.

## GET `/api/news`
Fetches environmental news.
- Response: `[{ title: string, source: string }]`
