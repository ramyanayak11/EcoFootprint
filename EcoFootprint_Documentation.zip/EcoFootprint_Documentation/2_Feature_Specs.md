# Feature Specifications

## 🌱 Activity Logging
The Activity Logging feature allows users to record both predefined and custom eco-friendly activities. When a user selects an activity, the system calculates the estimated CO₂ savings by checking a built-in lookup table of values. If the user defines a custom activity, they can provide their own CO₂ value, which is stored in the custom_emissions table along with their user ID. All logged activities are saved in the activities table, helping users track their daily environmental impact and build a history of their actions.

## 🧠 Custom Emissions
The Custom Emissions feature allows users to define their own activities if they do something that isn’t already listed. When adding a custom activity, users can provide their own estimated CO₂ savings value. This information is saved in the custom_emissions table along with the user’s ID, so the data stays linked to their account. This feature gives users the flexibility to track unique actions that are meaningful to them.

## 🎯 Goal Setting
With the Goal Setting feature, users can set personal sustainability goals by choosing a category, adding a task description, and setting a deadline. As they work toward these goals, they have the option to mark them as complete. Completed goals are later included in monthly summaries and contribute to the badge and achievement system. This feature helps users stay focused and motivated on their long-term environmental impact.

## 🏆 Achievements
The Achievements feature keeps track of how many activities a user completes in each category. For every five logged actions in a specific category, the user earns a badge to celebrate their progress. These achievements are saved in the achievements table, allowing users to collect and view their badges as they continue to engage with the platform. This system encourages users to stay active by rewarding their consistent efforts.

## 📰 News Feed
The News Feed provides users with up-to-date environmental news by making a request to the /api/news endpoint. This external API fetches relevant news articles focused on topics like climate change, sustainability, and environmental issues. The news feed is displayed on the user’s dashboard, keeping them informed and engaged with the latest developments in the environmental space.

## 👤 Profile Page
The Profile Page allows users to personalize their account by updating their name and profile picture. Uploaded avatar images are stored securely in the Supabase storage system, specifically under the avatars bucket. This feature gives users a more personal connection to the platform by letting them customize their profile to reflect their identity.
