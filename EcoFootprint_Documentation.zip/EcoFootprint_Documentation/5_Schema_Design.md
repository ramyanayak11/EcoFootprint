# Supabase Schema Design

## Table: activities
| Column    | Type     | Description              |
|-----------|----------|--------------------------|
| id        | UUID     | Primary key              |
| user_id   | UUID     | Foreign key to auth      |
| activity  | text     | Activity name            |
| date      | timestamp| Timestamp of logging     |

## Table: custom_emissions
| Column     | Type   | Description                |
|------------|--------|----------------------------|
| activity   | text   | Custom activity name       |
| user_id    | UUID   | Foreign key to auth.users  |
| co2_value  | float  | CO₂ value (kg)             |

## Table: goals
| Column    | Type     | Description           |
|-----------|----------|-----------------------|
| id        | int      | Primary key           |
| user_id   | UUID     | Foreign key           |
| text      | string   | Goal description      |
| deadline  | date     | Optional deadline     |
| completed | boolean  | Marked as done        |
| category  | string   | "Diet", "Waste", etc. |
