# Development Timeline

### March
- Mar 18: Supabase auth, project setup
- Mar 25: Activity tracker + CO₂ lookup table

### April
- Apr 2: Custom emissions logic + form
- Apr 9: Goal settings page + form
- Apr 15: Profile avatar upload
- Apr 20: Auth guard added to all pages
- Apr 27: Added achievements system

### May
- May 4: UI polish with Tailwind + Framer Motion
- May 9: Final feature testing
- May 12: Documentation + submission
