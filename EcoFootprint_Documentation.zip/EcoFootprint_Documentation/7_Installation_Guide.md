# Installation Guide

## Prerequisites
- Node.js (18+)
- Supabase project with tables and storage

## Steps
1. Clone the repo
2. Run `npm install`
3. Create `.env.local` with:

```
NEXT_PUBLIC_SUPABASE_URL=your_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_anon_key
```

4. Start the dev server: `npm run dev`
