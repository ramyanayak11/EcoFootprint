# Component Responsibilities

## /dashboard/page.tsx
- Logs activity, fetches news and user data
- Calculates CO₂ saved
- Handles custom activities

## /goal_settings/page.tsx
- Adds and updates user goals
- Renders MonthlySummary

## /profile/page.tsx
- Edits user profile and uploads avatar
- Protected route

## /achievements/page.tsx
- Displays badge count per category
- Calculates progress toward next badge

## /signin & /login
- Auth via Supabase
- Login creates user session
