# Deployment (Vercel)

## Steps
1. Push to GitHub
2. Connect repo to Vercel
3. Add environment variables in Vercel dashboard
4. Build command: `npm run build`
5. Output: `.next`

Ensure your `avatars` storage bucket is public-read.
