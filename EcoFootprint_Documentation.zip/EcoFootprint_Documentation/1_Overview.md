# EcoFootprint App – Overview

EcoFootprint is a web-based platform that helps users track their eco-friendly actions and understand their environmental impact. By logging daily activities, setting personal goals, and viewing their progress, users become more aware of how small lifestyle changes can contribute to a more sustainable future. The platform is designed to be user-friendly, secure, and informative, encouraging long-term engagement through goal tracking and progress visualization.

- **Next.js 14** (App Router)
- **Supabase** (for authentication, database, and storage)
- **Tailwind CSS** (styling)
- **Framer Motion** (animations)

## Core Modules
- **Activity Tracker**: Logs user actions and estimates CO₂ saved.
- **Custom Emissions**: Users can define new activities and CO₂ values.
- **Goal Setting**: Set environmental goals with deadlines and categories.
- **Achievements**: Earn badges based on tracked activity categories.
- **News Feed**: Get real-time environmental news.
- **Profile Management**: Upload profile images and manage account data.
